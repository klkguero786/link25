// AUTO REMOVE INDEX.JS CONTENTS //
console.log("This project is coming soon! Please check back later.")
process.exit(0)
// AUTO REMOVE INDEX.JS CONTENTS //